const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
require("dotenv").config();

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error(err));

// User schema
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  mobile: String,
  password: String,
});

const User = mongoose.model("User", userSchema);

async function createAdmin() {
  const password = "admin123";
  const hashedPassword = await bcrypt.hash(password, 10);

  const admin = new User({
    name: "Admin",
    email: "admin@example.com",
    mobile: "+911234567890",
    password: hashedPassword
  });

  await admin.save();
  console.log("Admin created successfully!");
  mongoose.disconnect();
}

createAdmin();
