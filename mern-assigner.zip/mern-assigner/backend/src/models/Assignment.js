const mongoose = require('mongoose');

const AssignmentSchema = new mongoose.Schema({
  agent: { type: mongoose.Schema.Types.ObjectId, ref: 'Agent', required: true },
  items: [{ type: mongoose.Schema.Types.ObjectId, ref: 'ListItem' }],
  createdAt: { type: Date, default: Date.now },
  notes: { type: String } // optional metadata
});

module.exports = mongoose.model('Assignment', AssignmentSchema);
