const mongoose = require("mongoose");

const listItemSchema = new mongoose.Schema({
  agent: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // links to the agent
  firstName: { type: String, required: true },
  phone: { type: String, required: true },
  notes: { type: String }, // optional notes field
});

module.exports = mongoose.model("ListItem", listItemSchema);
