// items is an array of ListItem documents (or IDs), agents is array of Agent IDs (must be length 5)
function distribute(items, agents) {
  const n = items.length;
  const a = agents.length;
  const base = Math.floor(n / a);
  const rem = n % a;
  const assignments = [];

  let idx = 0;
  for (let i = 0; i < a; i++) {
    const count = base + (i < rem ? 1 : 0);
    const chunk = items.slice(idx, idx + count);
    assignments.push({
      agentId: agents[i],
      items: chunk
    });
    idx += count;
  }
  return assignments; // array of { agentId, items }
}

module.exports = { distribute };
