const express = require("express");
const router = express.Router();
const multer = require("multer");
const fs = require("fs");
const csv = require("csv-parse");
const XLSX = require("xlsx");

const Agent = require("../models/User"); // or your Agent model
const ListItem = require("../models/ListItem"); // model for distributed list items

// Multer setup (temporary storage)
const upload = multer({ dest: "uploads/" });

// POST /api/upload
router.post("/", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: "No file uploaded" });

    const file = req.file.path;
    const ext = req.file.originalname.split(".").pop().toLowerCase();

    if (!["csv", "xls", "xlsx"].includes(ext)) {
      fs.unlinkSync(file);
      return res.status(400).json({ message: "Invalid file type" });
    }

    let data = [];

    if (ext === "csv") {
      // Parse CSV
      fs.createReadStream(file)
        .pipe(csv({ columns: true, trim: true }))
        .on("data", (row) => {
          if (row.FirstName && row.Phone) data.push(row);
        })
        .on("end", async () => {
          fs.unlinkSync(file);
          await distributeAndSave(data, res);
        })
        .on("error", (err) => {
          fs.unlinkSync(file);
          console.error(err);
          res.status(400).json({ message: "Invalid CSV format" });
        });
    } else {
      // Parse XLS/XLSX
      const workbook = XLSX.readFile(file);
      const sheetName = workbook.SheetNames[0];
      data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
      fs.unlinkSync(file);
      await distributeAndSave(data, res);
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Upload failed" });
  }
});

// Function to distribute items among agents and save
async function distributeAndSave(data, res) {
  try {
    const agents = await Agent.find();
    if (agents.length === 0) return res.status(400).json({ message: "No agents found" });

    const distributed = {};
    agents.forEach((a) => (distributed[a._id] = []));

    data.forEach((item, i) => {
      const agent = agents[i % agents.length];
      distributed[agent._id].push({
        firstName: item.FirstName || item.firstName || "",
        phone: item.Phone || item.phone || "",
        notes: item.Notes || item.notes || "",
      });
    });

    // Save all items in DB
    const savePromises = [];
    for (const agentId in distributed) {
      distributed[agentId].forEach((item) => {
        savePromises.push(
          ListItem.create({ agent: agentId, firstName: item.firstName, phone: item.phone, notes: item.notes })
        );
      });
    }
    await Promise.all(savePromises);

    res.json({ message: "Upload successful", distributed });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to save uploaded items" });
  }
}

module.exports = router;
