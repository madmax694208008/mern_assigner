const Agent = require('../models/Agent');

exports.createAgent = async (req, res) => {
  try {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'Forbidden' });
    const { name, email, mobile, password } = req.body;
    if (!name || !email || !mobile || !password) return res.status(400).json({ message: 'All fields required' });

    const exists = await Agent.findOne({ email });
    if (exists) return res.status(409).json({ message: 'Agent with email already exists' });

    const agent = new Agent({ name, email, mobile, password });
    await agent.save();
    res.status(201).json({ message: 'Agent created', agent: { id: agent._id, name: agent.name, email: agent.email } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.getAgents = async (req, res) => {
  try {
    const agents = await Agent.find().select('-password').lean();
    res.json({ agents });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};
