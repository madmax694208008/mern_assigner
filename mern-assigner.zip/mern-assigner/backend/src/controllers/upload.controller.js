const csvParse = require('csv-parse/lib/sync');
const ListItem = require('../models/ListItem');
const Assignment = require('../models/Assignment');
const Agent = require('../models/Agent');
const { distribute } = require('../utils/distribute');

exports.handleUpload = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: 'No file uploaded' });

    const ext = (req.file.originalname.match(/\.[^.]+$/) || [''])[0].toLowerCase();

    // For simplicity: only parse CSV here. For xlsx you would use 'xlsx' package to convert to csv.
    if (ext !== '.csv') return res.status(400).json({ message: 'Only CSV parsing implemented in this example. Convert xlsx/xls to CSV before uploading.' });

    const text = req.file.buffer.toString('utf8');
    const records = csvParse(text, { columns: true, skip_empty_lines: true, trim: true });

    // Validate columns: FirstName, Phone, Notes (case-insensitive)
    const normalized = records.map(r => {
      const keys = Object.keys(r);
      const lower = {};
      for (const k of keys) lower[k.toLowerCase().trim()] = r[k];
      return lower;
    });

    for (const row of normalized) {
      if (!('firstname' in row) || !('phone' in row)) {
        return res.status(400).json({ message: 'CSV must contain FirstName and Phone columns' });
      }
    }

    // create ListItem docs
    const itemsToSave = normalized.map(r => ({
      firstName: r.firstname || '',
      phone: r.phone || '',
      notes: r.notes || ''
    }));
    const createdItems = await ListItem.insertMany(itemsToSave);

    // fetch exactly 5 agents in order. If less than 5, fail or distribute among available agents; here require >=5
    const agents = await Agent.find().limit(5);
    if (agents.length < 5) return res.status(400).json({ message: 'At least 5 agents required to distribute lists' });
    const agentIds = agents.map(a => a._id);

    const assignments = distribute(createdItems.map(i => i._id), agentIds); // returns array of {agentId, items}

    const savedAssignments = [];
    for (const asg of assignments) {
      const doc = new Assignment({ agent: asg.agentId, items: asg.items });
      await doc.save();
      savedAssignments.push(doc);
    }

    // Optionally return assigned counts per agent
    const result = savedAssignments.map(a => ({ agent: a.agent, itemCount: a.items.length }));
    res.json({ message: 'File processed and distributed', result });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
