const multer = require('multer');
const path = require('path');

const storage = multer.memoryStorage();
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (['.csv', '.xlsx', '.xls'].includes(ext)) cb(null, true);
    else cb(new Error('Only csv, xlsx, xls allowed'));
  },
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB
});

module.exports = upload;
