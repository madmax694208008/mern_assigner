import React, { useState } from "react";
import axios from "../api/axios"; // Make sure baseURL points to http://localhost:5000/api/agents

function AddAgent() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("/", { name, email, mobile, password });
      setMessage(res.data.message || "Agent added successfully");
      setName(""); setEmail(""); setMobile(""); setPassword("");
    } catch (err) {
      setMessage(err.response?.data?.message || "Error adding agent");
    }
  };

  return (
    <div>
      <h2>Add Agent</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        /><br />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        /><br />
        <input
          type="text"
          placeholder="Mobile"
          value={mobile}
          onChange={(e) => setMobile(e.target.value)}
          required
        /><br />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        /><br />
        <button type="submit">Add Agent</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
}

export default AddAgent;
