import React, { useState } from "react";
import axios from "../api/axios"; // Make sure baseURL points to http://localhost:5000/api/upload

function UploadList() {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) {
      setMessage("Please select a file first");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await axios.post("/", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      setMessage(res.data.message || "Upload successful");
      setFile(null);
    } catch (err) {
      console.error(err.response?.data);
      setMessage(err.response?.data?.message || "Upload failed");
    }
  };

  return (
    <div>
      <h2>Upload CSV/XLS/XLSX</h2>
      <form onSubmit={handleUpload}>
        <input type="file" accept=".csv,.xls,.xlsx" onChange={handleFileChange} />
        <br /><br />
        <button type="submit">Upload</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
}

export default UploadList;
