import React from "react";
import { Link } from "react-router-dom";

function Dashboard() {
  return (
    <div>
      <h2>Dashboard</h2>
      <nav>
        <Link to="/add-agent">Add Agent</Link> |{" "}
        <Link to="/upload-list">Upload List</Link>
      </nav>
      <p>Welcome to the MERN Assigner Dashboard!</p>
    </div>
  );
}

export default Dashboard;
